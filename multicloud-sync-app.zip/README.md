# Multicloud File Sync App — Prototype

Follow README instructions to run.