from flask import Flask, jsonify, redirect, request
from dotenv import load_dotenv
import os
from oauth_providers import PROVIDERS, build_auth_url
from sync_engine import sync_between_providers

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev')

USER_STORE = {}

@app.route('/api/connect/<provider>')
def connect_provider(provider):
    if provider not in PROVIDERS:
        return jsonify({'error': 'unsupported provider'}), 400
    user_id = request.args.get('user_id', 'demo_user')
    state = f"user={user_id}"
    url = build_auth_url(provider, state=state)
    return jsonify({'auth_url': url})

@app.route('/api/callback/<provider>')
def callback(provider):
    user_id = 'demo_user'
    if user_id not in USER_STORE:
        USER_STORE[user_id] = {'connections': {}}
    USER_STORE[user_id]['connections'][provider] = {
        'access_token': f'fake_access_token_for_{provider}',
        'meta': {'provider': provider}
    }
    return jsonify({'status': 'connected', 'provider': provider})

@app.route('/api/status')
def status():
    user_id = request.args.get('user_id', 'demo_user')
    return jsonify(USER_STORE.get(user_id, {}))

@app.route('/api/sync', methods=['POST'])
def api_sync():
    data = request.json or {}
    user_id = data.get('user_id', 'demo_user')
    file_path = data.get('file_path', 'example.txt')
    user = USER_STORE.get(user_id, {})
    connections = user.get('connections', {})
    if not connections:
        return jsonify({'error': 'no connections found'}), 400
    result = sync_between_providers(connections, file_path)
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
